const POKE_API = 'https://pokeapi.co/api/v2';
const POKEMON_PER_PAGE = 18;

let allPokemon = [];
let filteredPokemon = [];
let currentPage = 1;
let selectedPokemonId = 1;
let currentFilter = 'all';
let typeFilterMap = {};

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
    await loadAllPokemon();
    loadPokemonDetails(1);
    setupEventListeners();
});

async function loadAllPokemon() {
    try {
        // Get all Pokémon (up to Gen 9: ~1025 Pokémon)
        const response = await fetch(`${POKE_API}/pokemon?limit=1025&offset=0`);
        const data = await response.json();
        
        allPokemon = data.results.map((p, index) => ({
            id: index + 1,
            name: p.name,
            url: p.url
        }));

        filteredPokemon = [...allPokemon];
        displayPokemonList();
    } catch (error) {
        console.error('Error loading Pokémon:', error);
    }
}

async function loadPokemonDetails(id) {
    try {
        const response = await fetch(`${POKE_API}/pokemon/${id}`);
        const pokemon = await response.json();
        
        selectedPokemonId = id;
        displayPokemonInfo(pokemon);
        updateActiveListItem(id);
    } catch (error) {
        console.error('Error loading Pokémon details:', error);
    }
}

function displayPokemonInfo(pokemon) {
    // Name and ID
    document.getElementById('pokemonName').textContent = pokemon.name;
    document.getElementById('pokemonId').textContent = `#${pokemon.id.toString().padStart(4, '0')}`;

    // Image
    const imageUrl = pokemon.sprites.other['official-artwork'].front_default || 
                     pokemon.sprites.front_default;
    document.getElementById('pokemonImage').src = imageUrl;

    // Types
    const typesHtml = pokemon.types.map(t => 
        `<span class="type-badge ${t.type.name}">${t.type.name}</span>`
    ).join('');
    document.getElementById('typeBadges').innerHTML = typesHtml;

    // Stats
    const statsHtml = pokemon.stats.map(stat => {
        const percentage = (stat.base_stat / 255) * 100;
        return `
            <div class="stat-row">
                <span class="stat-label">${stat.stat.name.slice(0, 3)}</span>
                <div class="stat-bar">
                    <div class="stat-bar-fill" style="width: ${percentage}%"></div>
                </div>
                <span class="stat-value">${stat.base_stat}</span>
            </div>
        `;
    }).join('');
    document.getElementById('statsDisplay').innerHTML = statsHtml;
}

function displayPokemonList() {
    const start = (currentPage - 1) * POKEMON_PER_PAGE;
    const end = start + POKEMON_PER_PAGE;
    const pagePokemons = filteredPokemon.slice(start, end);

    const listHtml = pagePokemons.map(pokemon => `
        <div class="pokemon-list-item ${pokemon.id === selectedPokemonId ? 'active' : ''}" 
             onclick="loadPokemonDetails(${pokemon.id})">
            <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokemon.id}.png`*
